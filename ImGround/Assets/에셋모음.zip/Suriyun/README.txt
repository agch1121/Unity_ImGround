This asset comes with a UnityToonShader package. Please import the UnityToonShader Shader package along with the asset.

If you encounter pink shader issue, please re-import assets with the shaders or manually import the shader at: https://docs.unity3d.com/Packages/com.unity.toonshader@0.9/manual/installation.html

Please note, this asset use preview shader package : Unity Toon Shader 0.9.4-preview
You could follow the updates at : https://docs.unity3d.com/Packages/com.unity.toonshader@0.9/manual/whats-new.html

Unity Toon Shader copyright © 2021 Unity Technologies.

--------------------------------------------------------------------------------------------------------------------
Asset Store Terms of Service and EULA : https://unity.com/legal/as-terms
--------------------------------------------------------------------------------------------------------------------

If you found any problem, please contact us.
Mail : Contact@suriyun.com
Site : www.suriyun.com
